/**
 * InstanceRegistry: maps playerId -> GameInstance | BattleSideInstance. Used by GameLoop and HudService to route tick/HUD.
 */

import type { GameInstance } from './GameInstance.js';
import type { BattleSideInstance } from '../battle/BattleSideInstance.js';

export type GameInstanceLike = GameInstance | BattleSideInstance;

const playerToInstance = new Map<string, GameInstanceLike>();

export function registerInstance(playerId: string, instance: GameInstanceLike): void {
  playerToInstance.set(playerId, instance);
}

export function unregisterInstance(playerId: string): void {
  playerToInstance.delete(playerId);
}

export function getInstanceByPlayer(playerId: string): GameInstanceLike | undefined {
  return playerToInstance.get(playerId);
}

/** All active instances (for tick loop). */
export function getAllInstances(): GameInstanceLike[] {
  return [...playerToInstance.values()];
}

export function hasInstance(playerId: string): boolean {
  return playerToInstance.has(playerId);
}
