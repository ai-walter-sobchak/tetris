/**
 * HUD message types sent from server to client UI.
 * Game HUD (score, level, lines, status) is sent every tick.
 * Leaderboard is sent on join and periodically (or after score submit).
 */

export interface LeaderboardRow {
  rank: number;
  playerId: string;
  name: string;
  score: number;
}

export interface LeaderboardPayload {
  status: 'online' | 'offline';
  updatedAtMs: number;
  rows: LeaderboardRow[];
  selfPlayerId?: string;
}

/** Battle-specific HUD data (both players and spectators). Backward-compat: additive only. */
export interface BattleHudPayload {
  roomCode?: string;
  status: string;
  youRole: 'A' | 'B' | 'spectator';
  playerA?: string;
  playerB?: string;
  spectatorsCount?: number;
  scoreA: number;
  scoreB: number;
  linesA: number;
  linesB: number;
  pendingA: number;
  pendingB: number;
  energy?: number;
  energyThreshold?: number;
  heldPowerUp?: string;
  effects?: string[];
  /** Board grids for HUD rendering (A = left, B = right). */
  boardA?: number[][];
  boardB?: number[][];
}

export interface HudPayload {
  score: number;
  level: number;
  lines: number;
  status: string;
  gameStarted: boolean;
  /** When present, client updates the leaderboard panel. */
  leaderboard?: LeaderboardPayload;
  /** 'solo' | 'battle'; when 'battle', battle object is present. */
  mode?: 'solo' | 'battle';
  /** Present when mode === 'battle'. */
  battle?: BattleHudPayload;
}
