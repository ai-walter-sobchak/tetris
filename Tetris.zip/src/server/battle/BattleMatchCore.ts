/**
 * BattleMatchCore: shared match state for head-to-head battle.
 * Owns two board states, independent per-player RNG streams; garbage via GarbageSystem.
 */

import type { TetrisState } from '../state/types.js';
import type { PieceTypeId } from '../state/types.js';
import { createInitialState, spawnNextPiece } from '../state/WorldState.js';
import { createRng } from '../util/rng.js';

function randomPieceType(rng: () => number): PieceTypeId {
  const n = Math.floor(rng() * 7);
  const clamped = ((n % 7) + 7) % 7;
  return (clamped + 1) as PieceTypeId;
}
import { tickGravity, collides, tryMove } from '../systems/TetrisSystem.js';
import type { HudPayload, BattleHudPayload } from '../schema/hudMessages.js';
import type { BattleSideGarbageState } from './GarbageSystem.js';
import {
  computeAttackLines,
  scheduleGarbage,
  applyDueGarbage,
  getGarbagePendingTotal,
  getDueGarbageCount,
  clearDueGarbageEntries,
} from './GarbageSystem.js';
import { GARBAGE_DELAY_MS } from './battleConfig.js';
import { addEnergyOnClear, tryGrantPowerUp, initBattleNextQueue, spawnNextPieceFromQueue } from './PowerUpSystem.js';

export type BattleMatchStatus = 'running' | 'finished';

export interface BattleMatchCore {
  readonly stateA: TetrisState;
  readonly stateB: TetrisState;
  readonly battleSideA: BattleSideGarbageState;
  readonly battleSideB: BattleSideGarbageState;
  readonly playerAId: string;
  readonly playerBId: string;
  matchStatus: BattleMatchStatus;
  winnerId: string | null;
  readonly matchSeed: number;
  garbageBatchCounter: number;
  /** For deterministic power-up grant RNG. */
  readonly powerUpRngSeedBase: number;
  lastPowerUpEvent?: string;
  eventFeed: string[];
  getHudForViewer(spectatorId: string): HudPayload;
}

function getRngSeed(state: TetrisState): number | undefined {
  const r = state.rngState;
  if (typeof r === 'number' && Number.isFinite(r)) return r;
  return state.seed;
}

function createBattleSideGarbageState(): BattleSideGarbageState {
  return {
    pendingGarbage: [],
    combo: 0,
    garbageAppliedTotal: 0,
    energy: 0,
    shieldCharges: 0,
  };
}

/**
 * Create a battle match core with two boards and garbage state per side.
 * Same match seed; independent RNG consumption per player (seedA = seed, seedB = seed + 1).
 * Only the tick leader (playerA) should call tick() each frame.
 */
export function createBattleMatchCore(
  playerAId: string,
  playerBId: string,
  seed?: number
): BattleMatchCore {
  const matchSeed = seed ?? (Math.floor(Math.random() * 0xffffffff) >>> 0);
  const powerUpRngSeedBase = ((matchSeed >>> 0) + 0x1337) >>> 0;
  const stateA = createInitialState(matchSeed);
  const stateB = createInitialState(matchSeed + 1);
  const battleSideA = createBattleSideGarbageState();
  const battleSideB = createBattleSideGarbageState();

  const rngObjA = createRng(getRngSeed(stateA));
  initBattleNextQueue(battleSideA, () => rngObjA.next(), stateA.nextPiece?.type);
  stateA.rngState = rngObjA.getState();
  const rngObjB = createRng(getRngSeed(stateB));
  initBattleNextQueue(battleSideB, () => rngObjB.next(), stateB.nextPiece?.type);
  stateB.rngState = rngObjB.getState();

  const core: BattleMatchCore = {
    stateA,
    stateB,
    battleSideA,
    battleSideB,
    playerAId,
    playerBId,
    matchStatus: 'running',
    winnerId: null,
    matchSeed,
    garbageBatchCounter: 0,
    powerUpRngSeedBase,
    eventFeed: [],
    getHudForViewer(_spectatorId: string): HudPayload {
      const payload: HudPayload = {
        score: 0,
        level: 1,
        lines: 0,
        status: 'BATTLE_SPECTATE',
        gameStarted: true,
      };
      payload.mode = 'battle';
      payload.battle = {
        status: core.matchStatus === 'running' ? 'Playing' : 'Finished',
        youRole: 'spectator',
        playerA: core.playerAId,
        playerB: core.playerBId,
        scoreA: core.stateA.score,
        scoreB: core.stateB.score,
        linesA: core.stateA.lines,
        linesB: core.stateB.lines,
        pendingA: getGarbagePendingTotal(core.battleSideA),
        pendingB: getGarbagePendingTotal(core.battleSideB),
        boardA: core.stateA.board,
        boardB: core.stateB.board,
      } as BattleHudPayload;
      return payload;
    },
  };
  return core;
}

/** True if this player is the tick leader (only their instance calls core.tick). */
export function isTickLeader(core: BattleMatchCore, playerId: string): boolean {
  return core.playerAId === playerId;
}

export type BattleSideLabel = 'A' | 'B';

/** Call when a piece locked with optional line clear (from gravity tick or hardDrop). Updates combo and schedules garbage. */
export function applyLineClearResult(
  core: BattleMatchCore,
  side: BattleSideLabel,
  clearedLines: number,
  nowMs: number,
  locked: boolean
): void {
  if (core.matchStatus !== 'running') return;
  const attacker = side === 'A' ? core.battleSideA : core.battleSideB;
  const defender = side === 'A' ? core.battleSideB : core.battleSideA;
  if (locked && clearedLines === 0) {
    attacker.combo = 0;
    return;
  }
  if (clearedLines > 0) {
    attacker.combo += 1;
    attacker.lastClearMs = nowMs;
    const attack = computeAttackLines(clearedLines, attacker.combo);
    if (attack > 0) {
      core.garbageBatchCounter += 1;
      scheduleGarbage(defender, attack, nowMs, GARBAGE_DELAY_MS, core.garbageBatchCounter);
      attacker.lastAttackSent = attack;
    }
    addEnergyOnClear(attacker, clearedLines);
    const sideSalt = side === 'A' ? 1 : 2;
    tryGrantPowerUp(attacker, core.powerUpRngSeedBase, core.garbageBatchCounter, sideSalt);
  }
}

export interface SideTickResult {
  clearedLines: number;
  /** True when a piece locked this tick (so we can reset combo on empty clear). */
  locked: boolean;
}

/**
 * Invariant: when battleSide.nextQueue exists, ALL piece spawns must use it (no RNG fallback for nextPiece).
 * Both doSpawn and tickGravity/lockPiece spawn paths go through the queue when nextQueue is present.
 */
function runSideTick(
  state: TetrisState,
  nowMs: number,
  deltaMs: number,
  battleSide?: BattleSideGarbageState
): SideTickResult {
  const result: SideTickResult = { clearedLines: 0, locked: false };
  if (state.gameStatus !== 'RUNNING') return result;
  const rngObj = createRng(getRngSeed(state));
  const realRng = (): number => rngObj.next();

  let rng: () => number = realRng;
  if (battleSide?.nextQueue) {
    const q = battleSide.nextQueue;
    rng = (): number => {
      while (q.length < 2) q.push(randomPieceType(realRng));
      const nextType = q[1];
      q.shift();
      q.push(randomPieceType(realRng));
      return (nextType - 0.5) / 7;
    };
  }

  const doSpawn = (): void => {
    if (battleSide?.nextQueue) {
      spawnNextPieceFromQueue(state, battleSide, realRng);
    } else {
      spawnNextPiece(state, realRng);
    }
    state.rngState = rngObj.getState();
  };

  if (!state.activePiece) {
    doSpawn();
    if (state.activePiece && collides(state.board, state.activePiece)) {
      state.gameStatus = 'GAME_OVER';
      state.activePiece = null;
    }
    return result;
  }

  if (state.softDropActive) {
    tryMove(state, 0, -1);
  }

  const effectiveDeltaMs = Math.min(500, Math.max(50, deltaMs));
  if (state.gravityAccumulatorMs === 0) {
    state.gravityAccumulatorMs = state.softDropActive ? 50 : state.gravityIntervalMs;
  }
  const lineClear = tickGravity(state, effectiveDeltaMs, rng, nowMs);
  if (lineClear) {
    result.locked = true;
    result.clearedLines = lineClear.linesCleared;
  }
  state.rngState = rngObj.getState();

  if (state.gameStatus === 'RUNNING' && !state.activePiece) {
    doSpawn();
    if (state.activePiece && collides(state.board, state.activePiece)) {
      state.gameStatus = 'GAME_OVER';
      state.activePiece = null;
    }
  }
  return result;
}

function endMatchGarbageTopOut(core: BattleMatchCore, winnerId: string, winnerLabel: string): void {
  if (core.matchStatus !== 'running') return;
  core.matchStatus = 'finished';
  core.winnerId = winnerId;
  core.eventFeed.push(`${winnerLabel} wins (garbage top-out)`);
}

/**
 * Advance both boards (gravity, spawn), process line-clear attacks, apply due garbage. Call once per frame from the tick leader only.
 * Single source of truth for clears is tickBattleMatchCore: only here do locked+clearedLines become combo/attack/garbage
 * (gravity locks from runSideTick, and hard-drop clears deferred via pendingLineClearFromInput from handleAction).
 */
export function tickBattleMatchCore(core: BattleMatchCore, deltaMs: number): void {
  if (core.matchStatus !== 'running') return;
  const nowMs = Date.now();

  if (core.battleSideA.pendingLineClearFromInput !== undefined) {
    const cleared = core.battleSideA.pendingLineClearFromInput;
    core.battleSideA.pendingLineClearFromInput = undefined;
    applyLineClearResult(core, 'A', cleared, nowMs, true);
  }
  if (core.battleSideB.pendingLineClearFromInput !== undefined) {
    const cleared = core.battleSideB.pendingLineClearFromInput;
    core.battleSideB.pendingLineClearFromInput = undefined;
    applyLineClearResult(core, 'B', cleared, nowMs, true);
  }

  const resultA = runSideTick(core.stateA, nowMs, deltaMs, core.battleSideA);
  const resultB = runSideTick(core.stateB, nowMs, deltaMs, core.battleSideB);

  const labelA = 'Player A';
  const labelB = 'Player B';

  if (resultA.locked) applyLineClearResult(core, 'A', resultA.clearedLines, nowMs, true);
  if (resultB.locked) applyLineClearResult(core, 'B', resultB.clearedLines, nowMs, true);

  const dueCountB = getDueGarbageCount(core.battleSideB, nowMs);
  if (dueCountB > 0 && (core.battleSideB.shieldCharges ?? 0) > 0) {
    clearDueGarbageEntries(core.battleSideB, nowMs);
    core.battleSideB.shieldCharges = 0;
    core.eventFeed.push(`Shield blocked ${dueCountB} incoming (due)`);
    /* Shield consumes exactly one charge per block; no further due garbage this tick for this side. */
  } else if (dueCountB > 0) {
    const dueB = applyDueGarbage(core.stateB, core.battleSideB, nowMs, core.matchSeed);
    if (dueB.toppedOut) {
      endMatchGarbageTopOut(core, core.playerAId, labelA);
      return;
    }
  }

  const dueCountA = getDueGarbageCount(core.battleSideA, nowMs);
  if (dueCountA > 0 && (core.battleSideA.shieldCharges ?? 0) > 0) {
    clearDueGarbageEntries(core.battleSideA, nowMs);
    core.battleSideA.shieldCharges = 0;
    core.eventFeed.push(`Shield blocked ${dueCountA} incoming (due)`);
    /* Shield consumes exactly one charge per block. */
  } else if (dueCountA > 0) {
    const dueA = applyDueGarbage(core.stateA, core.battleSideA, nowMs, core.matchSeed);
    if (dueA.toppedOut) {
      endMatchGarbageTopOut(core, core.playerBId, labelB);
      return;
    }
  }

  if (core.stateA.gameStatus === 'GAME_OVER' || core.stateB.gameStatus === 'GAME_OVER') {
    core.matchStatus = 'finished';
    core.winnerId =
      core.stateA.gameStatus === 'GAME_OVER'
        ? core.playerBId
        : core.playerAId;
  }
}
