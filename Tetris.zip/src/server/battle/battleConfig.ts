/**
 * Battle mode configuration.
 * Used by BattleRoomManager, BattleMatchCore, GarbageSystem, PowerUpSystem.
 */

/** Length of room code (e.g. 6 => "ABC123"). */
export const ROOM_CODE_LENGTH = 6;

/** Characters used for room codes (uppercase alphanumeric, no ambiguous). */
export const ROOM_CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

/** Default delay (ms) before garbage lines are applied after a line clear. */
export const GARBAGE_DELAY_MS = 500;

/** Attack lines sent per lines cleared in one lock (1/2/3/4 lines -> 0/1/2/4). */
export const ATTACK_TABLE: Record<number, number> = {
  1: 0,
  2: 1,
  3: 2,
  4: 4,
};

/** Energy per line cleared. */
export const ENERGY_PER_LINE = 1;

/** Energy threshold to gain one power-up charge (default 4). */
export const ENERGY_THRESHOLD = 4;

/** Jam power-up duration in ms. */
export const JAM_DURATION_MS = 2000;

/** When jammed, min ms between allowed left/right moves (~50% rate). */
export const JAM_MOVE_THROTTLE_MS = 100;

/** Max spectators per room (0 = unlimited). */
export const MAX_SPECTATORS_PER_ROOM = 0;
