/**
 * Power-up system: energy earning, grant, activation (Shield, Jam, Swap Queue).
 */

import type { TetrisState } from '../state/types.js';
import type { PieceState, PieceTypeId } from '../state/types.js';
import { createRng } from '../util/rng.js';
import { createNextPiece } from '../state/WorldState.js';
import { SPAWN_X, SPAWN_Y } from '../config/tetris.js';

let battlePieceIdCounter = 0;
function createBattlePiece(type: PieceTypeId, x: number, y: number): PieceState {
  return { id: `bp_${++battlePieceIdCounter}`, type, rotation: 0, x, y };
}
import type { BattleSideGarbageState } from './GarbageSystem.js';
import type { BattleMatchCore } from './BattleMatchCore.js';
import type { PowerUpId } from './PowerUps.js';
import { POWER_UP_IDS, POWER_UP_COUNT } from './PowerUps.js';
import { ENERGY_PER_LINE, ENERGY_THRESHOLD, JAM_DURATION_MS } from './battleConfig.js';

/** RNG returns [0,1); piece type 1..7. */
function randomPieceType(rng: () => number): PieceTypeId {
  const n = Math.floor(rng() * 7);
  const clamped = ((n % 7) + 7) % 7;
  return (clamped + 1) as PieceTypeId;
}

/**
 * Add energy for cleared lines. Call from single source of truth (tickBattleMatchCore) when applying line clear result.
 */
export function addEnergyOnClear(sideState: BattleSideGarbageState, clearedLines: number): void {
  if (clearedLines <= 0) return;
  sideState.energy = (sideState.energy ?? 0) + ENERGY_PER_LINE * clearedLines;
}

/**
 * If energy >= threshold and no held power-up, grant a random one (deterministic). Mutates side state.
 * Use powerUpRngSeedBase + batchCounter + sideSalt for RNG; no Math.random.
 */
export function tryGrantPowerUp(
  sideState: BattleSideGarbageState,
  powerUpRngSeedBase: number,
  garbageBatchCounter: number,
  sideSalt: number
): void {
  const energy = sideState.energy ?? 0;
  if (energy < ENERGY_THRESHOLD) return;
  if (sideState.heldPowerUp != null) return;
  sideState.energy = energy - ENERGY_THRESHOLD;
  const seed = ((powerUpRngSeedBase >>> 0) + 1337 + garbageBatchCounter * 7919 + sideSalt * 7877) >>> 0;
  const rng = createRng(seed);
  const index = Math.floor(rng.next() * POWER_UP_COUNT) % POWER_UP_COUNT;
  sideState.heldPowerUp = POWER_UP_IDS[index];
}

/**
 * Consume held power-up and apply effect. Returns true if one was used.
 */
export function activatePowerUp(
  core: BattleMatchCore,
  side: 'A' | 'B',
  nowMs: number
): boolean {
  const sideState = side === 'A' ? core.battleSideA : core.battleSideB;
  const held = sideState.heldPowerUp;
  if (held == null) return false;
  sideState.heldPowerUp = undefined;
  const label = side === 'A' ? 'A' : 'B';
  if (held === 'shield') {
    sideState.shieldCharges = (sideState.shieldCharges ?? 0) + 1;
    const msg = `${label} used Shield`;
    core.eventFeed.push(msg);
    core.lastPowerUpEvent = msg;
    return true;
  }
  if (held === 'jam') {
    const opponent = side === 'A' ? core.battleSideB : core.battleSideA;
    opponent.jamUntilMs = nowMs + JAM_DURATION_MS;
    const msg = `${label} used JAM`;
    core.eventFeed.push(msg);
    core.lastPowerUpEvent = msg;
    return true;
  }
  if (held === 'swap') {
    const opponentQueue = side === 'A' ? core.battleSideB.nextQueue : core.battleSideA.nextQueue;
    if (opponentQueue && opponentQueue.length >= 3) {
      const a = opponentQueue[0];
      opponentQueue[0] = opponentQueue[1];
      opponentQueue[1] = opponentQueue[2];
      opponentQueue[2] = a;
    }
    const msg = `${label} used Swap Queue`;
    core.eventFeed.push(msg);
    core.lastPowerUpEvent = msg;
    return true;
  }
  return false;
}

/**
 * Spawn next piece from battle queue; refill queue from rng. Mutates state and sideState.nextQueue.
 */
export function spawnNextPieceFromQueue(
  state: TetrisState,
  sideState: BattleSideGarbageState,
  rng: () => number
): void {
  let queue = sideState.nextQueue;
  if (!queue || queue.length < 2) {
    queue = [
      randomPieceType(rng),
      randomPieceType(rng),
      randomPieceType(rng),
    ];
    sideState.nextQueue = queue;
  }
  const type = queue[0] as PieceTypeId;
  state.activePiece = createBattlePiece(type, SPAWN_X, SPAWN_Y);
  queue.shift();
  queue.push(randomPieceType(rng));
  state.nextPiece = createNextPiece(queue[0] as PieceTypeId);
}

/**
 * Permute opponent's next 3 pieces (indices 0,1,2). Used by Swap power-up (also in activatePowerUp).
 */
export function swapOpponentQueue(opponentSideState: BattleSideGarbageState): void {
  const q = opponentSideState.nextQueue;
  if (!q || q.length < 3) return;
  const a = q[0];
  q[0] = q[1];
  q[1] = q[2];
  q[2] = a;
}

/**
 * Initialize nextQueue with 3 types. If firstType is provided (from state.nextPiece), use it as queue[0] and fill rest from rng.
 */
export function initBattleNextQueue(
  sideState: BattleSideGarbageState,
  rng: () => number,
  firstType?: PieceTypeId
): void {
  if (firstType != null) {
    sideState.nextQueue = [
      firstType,
      randomPieceType(rng),
      randomPieceType(rng),
    ];
  } else {
    sideState.nextQueue = [
      randomPieceType(rng),
      randomPieceType(rng),
      randomPieceType(rng),
    ];
  }
}
