/**
 * GarbageSystem: line-clear penalties in battle. Schedules and applies garbage with deterministic holes.
 */

import type { TetrisState } from '../state/types.js';
import type { CellValue, PieceTypeId } from '../state/types.js';
import { BOARD_WIDTH, BOARD_HEIGHT } from '../config/tetris.js';
import { ATTACK_TABLE, GARBAGE_DELAY_MS } from './battleConfig.js';
import { createRng } from '../util/rng.js';

export interface PendingGarbageEntry {
  id: number;
  applyAtMs: number;
  lines: number;
}

export type HeldPowerUp = 'shield' | 'jam' | 'swap';

export interface BattleSideGarbageState {
  pendingGarbage: PendingGarbageEntry[];
  combo: number;
  lastClearMs?: number;
  garbageAppliedTotal?: number;
  /** Last attack lines sent (for HUD status). */
  lastAttackSent?: number;
  /** Cleared lines from a hard drop in handleAction; consumed by tickBattleMatchCore (single source of truth). */
  pendingLineClearFromInput?: number;
  /** Power-up: energy (earned by clearing lines). */
  energy?: number;
  /** Power-up: held in inventory (1 slot). */
  heldPowerUp?: HeldPowerUp;
  /** Shield charges (0 or 1); consumed when blocking garbage. */
  shieldCharges?: number;
  /** Jammed until this timestamp (reduces left/right rate 50%). */
  jamUntilMs?: number;
  /** Last time a left/right move was allowed (for jam throttle). */
  lastJamMoveMs?: number;
  /** Next 3 piece types for preview and Swap Queue. */
  nextQueue?: PieceTypeId[];
}

/** Garbage block type (distinct from piece types 1–7). Use 8 for garbage. */
export const GARBAGE_CELL: CellValue = 8;

/**
 * Base attack from ATTACK_TABLE; bonus = max(0, combo - 1). Total = base + bonus.
 */
export function computeAttackLines(cleared: number, combo: number): number {
  const base = ATTACK_TABLE[cleared] ?? 0;
  const bonus = Math.max(0, combo - 1);
  return base + bonus;
}

/**
 * Schedule garbage to be applied to the defender after delayMs. Mutates defenderState.pendingGarbage.
 */
export function scheduleGarbage(
  defenderState: BattleSideGarbageState,
  lines: number,
  nowMs: number,
  delayMs: number,
  batchId: number
): void {
  if (lines <= 0) return;
  defenderState.pendingGarbage.push({
    id: batchId,
    applyAtMs: nowMs + delayMs,
    lines,
  });
}

/** Return total lines of due garbage without mutating. Used for shield check. */
export function getDueGarbageCount(defenderState: BattleSideGarbageState, nowMs: number): number {
  return defenderState.pendingGarbage
    .filter((e) => nowMs >= e.applyAtMs)
    .reduce((sum, e) => sum + e.lines, 0);
}

/** Remove due garbage entries without applying. Returns count removed. Used when shield blocks. */
export function clearDueGarbageEntries(defenderState: BattleSideGarbageState, nowMs: number): number {
  const due = defenderState.pendingGarbage.filter((e) => nowMs >= e.applyAtMs);
  const totalLines = due.reduce((sum, e) => sum + e.lines, 0);
  defenderState.pendingGarbage = defenderState.pendingGarbage.filter((e) => nowMs < e.applyAtMs);
  return totalLines;
}

/**
 * Apply all due garbage for the defender. Mutates defender's board and pendingGarbage.
 * Returns number of lines applied. Caller checks injectGarbageLines return for top-out.
 */
export function applyDueGarbage(
  tetrisState: TetrisState,
  defenderState: BattleSideGarbageState,
  nowMs: number,
  matchSeed: number
): { applied: number; toppedOut: boolean } {
  const due = defenderState.pendingGarbage.filter((e) => nowMs >= e.applyAtMs);
  if (due.length === 0) return { applied: 0, toppedOut: false };
  let totalLines = 0;
  for (const entry of due) {
    totalLines += entry.lines;
  }
  defenderState.pendingGarbage = defenderState.pendingGarbage.filter((e) => nowMs < e.applyAtMs);
  if (totalLines <= 0) return { applied: 0, toppedOut: false };
  const holeSeeds = due.flatMap((e) =>
    Array.from({ length: e.lines }, (_, lineIndex) =>
      deriveHoleSeed(matchSeed, e.id, lineIndex)
    )
  );
  const toppedOut = injectGarbageLines(tetrisState, totalLines, holeSeeds);
  defenderState.garbageAppliedTotal = (defenderState.garbageAppliedTotal ?? 0) + totalLines;
  return { applied: totalLines, toppedOut };
}

function deriveHoleSeed(matchSeed: number, batchId: number, lineIndex: number): number {
  return ((matchSeed >>> 0) + batchId * 7919 + lineIndex * 7877) >>> 0;
}

/**
 * Add garbage rows at bottom; shift board up. Each row has one hole (deterministic from holeSeeds).
 * Returns true if any block was pushed above the playable area (top-out).
 */
export function injectGarbageLines(
  state: TetrisState,
  linesToAdd: number,
  holeSeeds: number[]
): boolean {
  const board = state.board;
  if (!board?.length || board.length !== BOARD_HEIGHT || !board[0] || board[0].length !== BOARD_WIDTH) {
    return true;
  }
  if (linesToAdd <= 0) return false;

  const width = BOARD_WIDTH;
  const height = BOARD_HEIGHT;

  const rowsToRemove = linesToAdd;
  let hadBlockInRemoved = false;
  for (let y = 0; y < rowsToRemove && y < board.length; y++) {
    for (let x = 0; x < width; x++) {
      if (board[y][x] !== 0) hadBlockInRemoved = true;
    }
  }
  if (hadBlockInRemoved) return true;

  const newRows: CellValue[][] = [];
  for (let i = 0; i < linesToAdd; i++) {
    const seed = holeSeeds[i] ?? (i * 31337);
    const rng = createRng(seed);
    const holeX = Math.floor(rng.next() * width);
    const row: CellValue[] = [];
    for (let x = 0; x < width; x++) {
      row.push(x === holeX ? 0 : GARBAGE_CELL);
    }
    newRows.push(row);
  }

  for (let r = 0; r < rowsToRemove; r++) {
    board.shift();
  }
  for (const row of newRows) {
    board.push(row);
  }
  return false;
}

export function getGarbagePendingTotal(state: BattleSideGarbageState): number {
  return state.pendingGarbage.reduce((sum, e) => sum + e.lines, 0);
}
