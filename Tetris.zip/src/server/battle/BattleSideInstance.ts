/**
 * BattleSideInstance: one player's view of a battle match.
 * Implements the same contract as GameInstance so the loop and HUD work unchanged.
 * Both sides reference the same BattleMatchCore; only the tick leader advances core.tick().
 */

import type { World } from 'hytopia';
import type { Plot } from '../plots/PlotManager.js';
import type { TetrisState } from '../state/types.js';
import type { InputAction } from '../systems/InputSystem.js';
import type { LineClearResult } from '../systems/TetrisSystem.js';
import { tryMove, tryRotate, hardDrop } from '../systems/TetrisSystem.js';
import { renderInstance, clearInstanceRenderCache } from '../game/RenderSystemInstance.js';
import type { HudPayload, BattleHudPayload, LeaderboardPayload } from '../schema/hudMessages.js';
import { buildHudPayload } from '../services/HudService.js';
import type { BattleMatchCore } from './BattleMatchCore.js';
import { isTickLeader, tickBattleMatchCore } from './BattleMatchCore.js';
import { createRng } from '../util/rng.js';
import { getGarbagePendingTotal } from './GarbageSystem.js';
import { activatePowerUp } from './PowerUpSystem.js';
import { JAM_MOVE_THROTTLE_MS, ENERGY_THRESHOLD } from './battleConfig.js';

const RENDER_THROTTLE_MS = 50;

export type BattleSide = 'A' | 'B';

export class BattleSideInstance {
  readonly playerId: string;
  readonly side: BattleSide;
  readonly core: BattleMatchCore;
  readonly plot: Plot;
  gameStarted: boolean;
  dirty: boolean;
  lastRenderMs: number;
  pendingLineClearBurst: LineClearResult | null;
  pendingPieceLock: boolean;

  constructor(playerId: string, side: BattleSide, core: BattleMatchCore, plot: Plot) {
    this.playerId = playerId;
    this.side = side;
    this.core = core;
    this.plot = plot;
    this.gameStarted = true;
    this.dirty = true;
    this.lastRenderMs = 0;
    this.pendingLineClearBurst = null;
    this.pendingPieceLock = false;
  }

  get state(): TetrisState {
    return this.side === 'A' ? this.core.stateA : this.core.stateB;
  }

  setGameStarted(): void {
    if (this.gameStarted) return;
    this.gameStarted = true;
    this.dirty = true;
  }

  handleAction(action: InputAction | null, softDropActive: boolean): void {
    const state = this.state;
    state.softDropActive = softDropActive;
    if (action === 'reset') return;
    if (state.gameStatus !== 'RUNNING' || !action || action === 'start') return;
    if (action === 'usePowerUp') {
      activatePowerUp(this.core, this.side, Date.now());
      this.dirty = true;
      return;
    }
    const nowMs = Date.now();
    const sideState = this.side === 'A' ? this.core.battleSideA : this.core.battleSideB;
    if (action === 'left' || action === 'right') {
      if (nowMs < (sideState.jamUntilMs ?? 0)) {
        const last = sideState.lastJamMoveMs ?? 0;
        if (nowMs - last < JAM_MOVE_THROTTLE_MS) return;
        sideState.lastJamMoveMs = nowMs;
      }
    }
    if (action === 'left') tryMove(state, -1, 0);
    else if (action === 'right') tryMove(state, 1, 0);
    else if (action === 'hardDrop') {
      const seed = state.rngState ?? state.seed;
      const rngObj = createRng(seed);
      const lineClear = hardDrop(state, () => rngObj.next(), Date.now());
      state.rngState = rngObj.getState();
      this.pendingPieceLock = true;
      if (lineClear.linesCleared > 0) this.pendingLineClearBurst = lineClear;
      const sideState = this.side === 'A' ? this.core.battleSideA : this.core.battleSideB;
      sideState.pendingLineClearFromInput = lineClear.linesCleared;
    }
    this.dirty = true;
  }

  tick(deltaMs: number): void {
    if (isTickLeader(this.core, this.playerId)) {
      tickBattleMatchCore(this.core, deltaMs);
    }
    this.dirty = true;
  }

  getHudPayload(leaderboard?: LeaderboardPayload): HudPayload {
    const payload = buildHudPayload(this.state, this.gameStarted, leaderboard);
    const sideState = this.side === 'A' ? this.core.battleSideA : this.core.battleSideB;
    const incoming = getGarbagePendingTotal(this.side === 'A' ? this.core.battleSideB : this.core.battleSideA);
    const energy = sideState.energy ?? 0;
    const heldPowerUp = sideState.heldPowerUp
      ? sideState.heldPowerUp.charAt(0).toUpperCase() + sideState.heldPowerUp.slice(1)
      : (sideState.shieldCharges ? 'Shield' : undefined);
    const effects: string[] = [];
    if ((sideState.jamUntilMs ?? 0) > Date.now()) effects.push('Jammed');
    if ((sideState.shieldCharges ?? 0) > 0) effects.push('Shield');
    payload.mode = 'battle';
    payload.status = payload.status;
    payload.battle = {
      status: this.core.matchStatus === 'running' ? 'Playing' : 'Finished',
      youRole: this.side,
      playerA: this.core.playerAId,
      playerB: this.core.playerBId,
      scoreA: this.core.stateA.score,
      scoreB: this.core.stateB.score,
      linesA: this.core.stateA.lines,
      linesB: this.core.stateB.lines,
      pendingA: getGarbagePendingTotal(this.core.battleSideA),
      pendingB: getGarbagePendingTotal(this.core.battleSideB),
      energy,
      energyThreshold: ENERGY_THRESHOLD,
      heldPowerUp,
      effects: effects.length ? effects : undefined,
      boardA: this.core.stateA.board,
      boardB: this.core.stateB.board,
    } as BattleHudPayload;
    return payload;
  }

  /** Render this side's board into the booth at this.plot.origin (booth-based plot from BattleRoomManager). */
  render(world: World): void {
    const now = Date.now();
    if (!this.dirty && now - this.lastRenderMs < RENDER_THROTTLE_MS) return;
    this.dirty = false;
    this.lastRenderMs = now;
    renderInstance(this.state, world, this.plot.origin, this.plot.id);
  }

  reset(_seed?: number): void {
    this.dirty = true;
  }

  clearAndDestroy(world: World): void {
    clearInstanceRenderCache(world, this.plot);
  }
}
