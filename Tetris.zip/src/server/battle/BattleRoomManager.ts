/**
 * BattleRoomManager: create/join/spectate/leave battle rooms and start matches.
 * tryStartPendingBattles / endBattleMatch integrate with InstanceRegistry and PlotManager.
 */

import type { World } from 'hytopia';
import {
  ROOM_CODE_LENGTH,
  ROOM_CODE_CHARS,
} from './battleConfig.js';
import {
  type BattleRoom,
  createBattleRoom,
} from './BattleRoom.js';
import { createBattleMatchCore } from './BattleMatchCore.js';
import { BattleSideInstance } from './BattleSideInstance.js';
import { createBattlePlotView } from './battlePlotView.js';
import { registerInstance, unregisterInstance, getInstanceByPlayer } from '../game/InstanceRegistry.js';
import { GameInstance } from '../game/GameInstance.js';
import { assignPlot, releasePlot } from '../plots/PlotManager.js';
import type { Plot } from '../plots/PlotManager.js';
import { reserveBooth, releaseBooth } from '../plots/BattlePlotManager.js';
import { getReactorBounds, buildReactorArcadeBooth } from '../plots/ReactorArcade.js';
import { PlayerManager } from 'hytopia';

const roomsByCode = new Map<string, BattleRoom>();
const roomIdToRoom = new Map<string, BattleRoom>();
/** playerId -> room (whether as host, playerA, playerB, or spectator). */
const playerToRoom = new Map<string, BattleRoom>();

let roomIdCounter = 0;

function generateRoomCode(): string {
  let code: string;
  do {
    code = '';
    for (let i = 0; i < ROOM_CODE_LENGTH; i++) {
      code += ROOM_CODE_CHARS[Math.floor(Math.random() * ROOM_CODE_CHARS.length)];
    }
  } while (roomsByCode.has(code));
  return code;
}

function removePlayerFromRoom(playerId: string, room: BattleRoom): void {
  room.spectators.delete(playerId);
  if (room.playerAId === playerId) room.playerAId = null;
  if (room.playerBId === playerId) room.playerBId = null;
  playerToRoom.delete(playerId);
}

function disbandRoom(room: BattleRoom): void {
  for (const pid of room.spectators) playerToRoom.delete(pid);
  if (room.playerAId) playerToRoom.delete(room.playerAId);
  if (room.playerBId) playerToRoom.delete(room.playerBId);
  roomsByCode.delete(room.code);
  roomIdToRoom.delete(room.roomId);
}

/**
 * Create a new battle room. Caller becomes host and playerA.
 */
export function createRoom(playerId: string): { ok: true; room: BattleRoom; code: string } | { ok: false; message: string } {
  if (playerToRoom.has(playerId)) {
    return { ok: false, message: 'You are already in a battle room. Use /battle leave first.' };
  }
  const roomId = `battle_${++roomIdCounter}_${Date.now()}`;
  const code = generateRoomCode();
  const room = createBattleRoom(roomId, code, playerId);
  roomsByCode.set(code, room);
  roomIdToRoom.set(roomId, room);
  playerToRoom.set(playerId, room);
  return { ok: true, room, code };
}

/**
 * Join a room as playerB by code.
 */
export function joinRoom(playerId: string, code: string): { ok: true; room: BattleRoom } | { ok: false; message: string } {
  if (playerToRoom.has(playerId)) {
    return { ok: false, message: 'You are already in a battle room. Use /battle leave first.' };
  }
  const room = roomsByCode.get(code.toUpperCase());
  if (!room) return { ok: false, message: 'Room not found. Check the code.' };
  if (room.status !== 'waiting') return { ok: false, message: 'Room is not waiting for players.' };
  if (room.playerBId != null) return { ok: false, message: 'Room is full.' };
  room.playerBId = playerId;
  playerToRoom.set(playerId, room);
  return { ok: true, room };
}

/**
 * Join a room as spectator. Spectators are not registered in InstanceRegistry.
 */
export function spectateRoom(playerId: string, code: string): { ok: true; room: BattleRoom } | { ok: false; message: string } {
  if (playerToRoom.has(playerId)) {
    return { ok: false, message: 'You are already in a battle room. Use /battle leave first.' };
  }
  const room = roomsByCode.get(code.toUpperCase());
  if (!room) return { ok: false, message: 'Room not found. Check the code.' };
  room.spectators.add(playerId);
  playerToRoom.set(playerId, room);
  return { ok: true, room };
}

/**
 * Leave current room (any role). If host leaves, room is disbanded.
 */
export function leaveRoom(playerId: string): { ok: true; message: string } | { ok: false; message: string } {
  const room = playerToRoom.get(playerId);
  if (!room) return { ok: false, message: 'You are not in a battle room.' };
  const wasHost = room.hostId === playerId;
  removePlayerFromRoom(playerId, room);
  if (wasHost) disbandRoom(room);
  return { ok: true, message: 'Left battle room.' };
}

/**
 * Start the match (host only). Phase 1: only validates and sets status; actual match start in Phase 2.
 */
export function startMatch(playerId: string): { ok: true; room: BattleRoom } | { ok: false; message: string } {
  const room = playerToRoom.get(playerId);
  if (!room) return { ok: false, message: 'You are not in a battle room.' };
  if (room.hostId !== playerId) return { ok: false, message: 'Only the host can start the match.' };
  if (room.status !== 'waiting') return { ok: false, message: 'Match already started or finished.' };
  if (room.playerBId == null) return { ok: false, message: 'Need two players to start. Wait for someone to /battle join ' + room.code };
  room.status = 'ready_to_start';
  return { ok: true, room };
}

export function getRoomByPlayer(playerId: string): BattleRoom | undefined {
  return playerToRoom.get(playerId);
}

export function getRoomByCode(code: string): BattleRoom | undefined {
  return roomsByCode.get(code.toUpperCase());
}

export function getRoomByRoomId(roomId: string): BattleRoom | undefined {
  return roomIdToRoom.get(roomId);
}

/** Rooms that have an active match (for spectator HUD broadcast). Spectators are not in InstanceRegistry. */
export function getRoomsWithActiveMatch(): BattleRoom[] {
  const out: BattleRoom[] = [];
  for (const room of roomIdToRoom.values()) {
    if (room.status === 'in_progress' && room.matchCore) out.push(room);
  }
  return out;
}

/**
 * Teleport a player's camera to a world position (used for booth spawns).
 */
function teleportPlayerTo(world: World, playerId: string, pos: { x: number; y: number; z: number }): void {
  const player = PlayerManager.instance.getConnectedPlayersByWorld(world).find((p) => p.id === playerId);
  if (player) player.camera.setAttachedToPosition(pos);
}

/**
 * Start any rooms that are ready_to_start: reserve booth, clear solo instances, create battle core and sides, register, teleport.
 * If no booth is available, set room back to waiting and message host.
 */
export function tryStartPendingBattles(world: World): void {
  const toStart: BattleRoom[] = [];
  for (const room of roomIdToRoom.values()) {
    if (room.status === 'ready_to_start' && room.playerAId && room.playerBId) toStart.push(room);
  }
  for (const room of toStart) {
    const booth = reserveBooth(room.roomId);
    if (!booth) {
      room.status = 'waiting';
      const host = PlayerManager.instance.getConnectedPlayersByWorld(world).find((p) => p.id === room.hostId);
      if (host) world.chatManager.sendPlayerMessage(host, 'No battle booth available. Try again later.');
      continue;
    }
    room.boothId = booth.id;
    room.spectatorTeleported = new Set<string>();

    const aId = room.playerAId!;
    const bId = room.playerBId!;
    const instA = getInstanceByPlayer(aId);
    const instB = getInstanceByPlayer(bId);
    if (instA && instA instanceof GameInstance) {
      instA.clearAndDestroy(world);
      unregisterInstance(aId);
      releasePlot(aId);
    }
    if (instB && instB instanceof GameInstance) {
      instB.clearAndDestroy(world);
      unregisterInstance(bId);
      releasePlot(bId);
    }
    const core = createBattleMatchCore(aId, bId);
    room.matchCore = core;
    room.status = 'in_progress';

    // Build the same reactor shell as solo so each battle board looks like a solo plot.
    const reactorPlotFromOrigin = (origin: { x: number; y: number; z: number }, id: string): Plot => {
      const { shellBounds, boardBounds } = getReactorBounds(origin);
      return {
        id,
        origin: { ...origin },
        shellBounds: { ...shellBounds },
        boardBounds: { ...boardBounds },
        bounds: { ...shellBounds },
        spawnPoint: { ...origin },
      };
    };
    buildReactorArcadeBooth(world, reactorPlotFromOrigin(booth.originA, `${booth.id}_shell_A`));
    buildReactorArcadeBooth(world, reactorPlotFromOrigin(booth.originB, `${booth.id}_shell_B`));

    const plotA = createBattlePlotView(`battle_${room.roomId}_A`, booth.originA);
    const plotB = createBattlePlotView(`battle_${room.roomId}_B`, booth.originB);
    const sideA = new BattleSideInstance(aId, 'A', core, plotA);
    const sideB = new BattleSideInstance(bId, 'B', core, plotB);
    registerInstance(aId, sideA);
    registerInstance(bId, sideB);

    teleportPlayerTo(world, aId, booth.spawnA);
    teleportPlayerTo(world, bId, booth.spawnB);
    for (const spectatorId of room.spectators) {
      teleportPlayerTo(world, spectatorId, booth.spawnSpectator);
      room.spectatorTeleported!.add(spectatorId);
    }
  }
}

/**
 * End a battle match: clear both sides' render (booth bounds only), release booth, unregister, return players to solo.
 */
export function endBattleMatch(world: World, room: BattleRoom): void {
  if (room.status === 'finished') return;
  room.status = 'finished';
  const aId = room.playerAId;
  const bId = room.playerBId;
  const instA = aId ? getInstanceByPlayer(aId) : undefined;
  const instB = bId ? getInstanceByPlayer(bId) : undefined;
  if (instA) {
    instA.clearAndDestroy(world);
    unregisterInstance(aId!);
  }
  if (instB) {
    instB.clearAndDestroy(world);
    unregisterInstance(bId!);
  }
  room.matchCore = undefined;
  releaseBooth(room.roomId);
  room.boothId = undefined;
  room.spectatorTeleported = undefined;
  if (aId) {
    const plot = assignPlot(aId);
    if (plot) {
      const solo = new GameInstance(plot, aId);
      registerInstance(aId, solo);
      solo.render(world);
    }
  }
  if (bId) {
    const plot = assignPlot(bId);
    if (plot) {
      const solo = new GameInstance(plot, bId);
      registerInstance(bId, solo);
      solo.render(world);
    }
  }
}
