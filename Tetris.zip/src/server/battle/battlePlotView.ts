/**
 * Battle plot view: Plot-compatible shape for rendering and clearing battle boards.
 * Phase 5 will use BattleBooth origins; Phase 2 uses placeholder origins.
 */

import type { Plot } from '../plots/PlotManager.js';
import { BOARD_WIDTH, BOARD_HEIGHT } from '../config/tetris.js';

/** Board bounds from origin. Depth=1: maxZ = origin.z + 1 (inclusive; matches BattleBooth and clearPlotRegion). */
function boundsFromOrigin(origin: { x: number; y: number; z: number }) {
  return {
    minX: origin.x,
    maxX: origin.x + BOARD_WIDTH - 1,
    minY: origin.y,
    maxY: origin.y + BOARD_HEIGHT - 1,
    minZ: origin.z,
    maxZ: origin.z + 1,
  };
}

/**
 * Create a Plot-compatible view for a battle board (so we can use renderInstance and clearInstanceRenderCache).
 */
export function createBattlePlotView(
  id: string,
  origin: { x: number; y: number; z: number }
): Plot {
  const boardBounds = boundsFromOrigin(origin);
  return {
    id,
    origin: { ...origin },
    shellBounds: { ...boardBounds },
    boardBounds: { ...boardBounds },
    bounds: { ...boardBounds },
    spawnPoint: { ...origin },
  };
}
