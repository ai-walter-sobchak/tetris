import type { BattleMatchCore } from './BattleMatchCore.js';

/**
 * BattleRoom: one head-to-head match lobby (and later match).
 * Contains host, playerA, playerB, spectators, status.
 * Match core reference is set when match starts (Phase 2).
 */
export type BattleRoomStatus = 'waiting' | 'ready_to_start' | 'in_progress' | 'finished';

export interface BattleRoom {
  /** Unique room id (internal). */
  roomId: string;
  /** Short code for join/spectate (e.g. "ABC123"). */
  code: string;
  /** Player who created the room. */
  hostId: string;
  /** First player slot (host is typically playerA). */
  playerAId: string | null;
  /** Second player slot. */
  playerBId: string | null;
  /** Spectator player ids (not in instance registry). */
  spectators: Set<string>;
  status: BattleRoomStatus;
  /** Set when match starts (Phase 2). */
  matchCore?: BattleMatchCore;
  /** Reserved booth id when match is in progress. */
  boothId?: string;
  /** Spectators we have already teleported to booth this match (one-time per spectator). */
  spectatorTeleported?: Set<string>;
}

export function createBattleRoom(roomId: string, code: string, hostId: string): BattleRoom {
  return {
    roomId,
    code,
    hostId,
    playerAId: hostId,
    playerBId: null,
    spectators: new Set(),
    status: 'waiting',
  };
}
