/**
 * Power-up types and constants for battle.
 */

export type PowerUpId = 'shield' | 'jam' | 'swap';

export const POWER_UP_IDS: PowerUpId[] = ['shield', 'jam', 'swap'];

export const POWER_UP_COUNT = POWER_UP_IDS.length;
