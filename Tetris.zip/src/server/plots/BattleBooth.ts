/**
 * BattleBooth: physical arena for one battle match. Board origins and bounds for rendering/clearing.
 *
 * Bounds convention: min/max are INCLUSIVE. Depth=1 means the board is a single Z-slice at origin.z.
 * We set max.z = origin.z + 1 so that (1) depth is unambiguous and (2) clearPlotRegion (inclusive
 * loop z <= maxZ) clears the rendered slice and one extra; the extra is harmless and matches
 * PlotManager/ReactorArcade boardBounds depth usage.
 */

import { BOARD_WIDTH, BOARD_HEIGHT } from '../config/tetris.js';

export type Vec3 = { x: number; y: number; z: number };

export interface BattleBooth {
  id: string;
  originA: Vec3;
  originB: Vec3;
  boundsA: { min: Vec3; max: Vec3 };
  boundsB: { min: Vec3; max: Vec3 };
  spawnA: Vec3;
  spawnB: Vec3;
  spawnSpectator: Vec3;
  spectatorLookAt?: Vec3;
}

/** X offset so Board B is to the right of Board A (side-by-side, same Z). */
const BOARD_SPACING_X = 14;

/** Spawn in front of both boards so both players see both boards (head-to-head arcade style). */
const SPAWN_OFFSET_Y = 1;
const SPAWN_OFFSET_Z = 8;

/**
 * Create a battle booth. Boards are side-by-side along X (A left, B right) at the same Z.
 * Far enough from solo plots (0..120 X, 0..40 Z) so we don't overlap the reactor shell,
 * but close enough (~130 blocks) so chunks load when players are teleported here.
 */
export function createBattleBooth(index: number): BattleBooth {
  const baseX = -130 - index * 35;
  const baseY = 0;
  const baseZ = -90;

  const originA: Vec3 = { x: baseX, y: baseY, z: baseZ };
  const originB: Vec3 = { x: baseX + BOARD_SPACING_X, y: baseY, z: baseZ };

  const boundsA = {
    min: { x: originA.x, y: originA.y, z: originA.z },
    max: {
      x: originA.x + BOARD_WIDTH - 1,
      y: originA.y + BOARD_HEIGHT - 1,
      z: originA.z + 1,
    },
  };
  const boundsB = {
    min: { x: originB.x, y: originB.y, z: originB.z },
    max: {
      x: originB.x + BOARD_WIDTH - 1,
      y: originB.y + BOARD_HEIGHT - 1,
      z: originB.z + 1,
    },
  };

  const centerX = baseX + (BOARD_WIDTH + BOARD_SPACING_X) / 2 - 0.5;
  const spawnZ = baseZ + SPAWN_OFFSET_Z;
  const spawnA: Vec3 = { x: Math.round(centerX), y: baseY + SPAWN_OFFSET_Y, z: spawnZ };
  const spawnB: Vec3 = { x: Math.round(centerX), y: baseY + SPAWN_OFFSET_Y, z: spawnZ };
  const spawnSpectator: Vec3 = { x: Math.round(centerX), y: baseY + 2, z: spawnZ + 4 };
  const spectatorLookAt: Vec3 = {
    x: Math.round(centerX),
    y: baseY + Math.floor(BOARD_HEIGHT / 2),
    z: baseZ,
  };

  return {
    id: `battle_booth_${index}`,
    originA,
    originB,
    boundsA,
    boundsB,
    spawnA,
    spawnB,
    spawnSpectator,
    spectatorLookAt,
  };
}
