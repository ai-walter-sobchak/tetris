/**
 * BattlePlotManager: pool of battle booths. Reserve/release per room. Does not touch solo PlotManager.
 */

import type { BattleBooth } from './BattleBooth.js';
import { createBattleBooth } from './BattleBooth.js';

const DEFAULT_BOOTH_POOL_SIZE = 2;

let booths: BattleBooth[] = [];
const roomToBooth = new Map<string, BattleBooth>();
const boothToRoom = new Map<string, string>();

/**
 * Initialize the booth pool. Call once at world start (e.g. from index after initPlots).
 */
export function initBattleBooths(count: number = DEFAULT_BOOTH_POOL_SIZE): void {
  if (booths.length > 0) return;
  booths = [];
  for (let i = 0; i < count; i++) {
    booths.push(createBattleBooth(i));
  }
}

/**
 * Reserve a booth for this room. Returns the booth or null if none available.
 */
export function reserveBooth(roomId: string): BattleBooth | null {
  if (roomToBooth.has(roomId)) return roomToBooth.get(roomId)!;
  const booth = booths.find((b) => !boothToRoom.has(b.id));
  if (!booth) return null;
  boothToRoom.set(booth.id, roomId);
  roomToBooth.set(roomId, booth);
  return booth;
}

/**
 * Release the booth assigned to this room. Idempotent.
 */
export function releaseBooth(roomId: string): void {
  const booth = roomToBooth.get(roomId);
  if (!booth) return;
  roomToBooth.delete(roomId);
  boothToRoom.delete(booth.id);
}

/**
 * Get the booth currently assigned to this room, if any.
 */
export function getBoothByRoom(roomId: string): BattleBooth | null {
  return roomToBooth.get(roomId) ?? null;
}
