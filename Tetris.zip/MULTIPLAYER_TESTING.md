# Multi-Player Presence — How to Test

## Prerequisites

- Server running (`npm run dev` or equivalent).
- Two different browser windows (or one normal + one incognito) so you have two distinct HYTOPIA sessions.

## Manual Test Steps (2 Players)

### 1. First player joins

1. Open the game in **Browser A** and join the world.
2. **Expected:** Player gets a plot; camera shows their Tetris board. HUD shows Score 0, Level 1, Lines 0, "Click Start to begin."
3. Type `/myplot` in chat. **Expected:** Reply like `Your plot: plot_0 at (0,0,0).`
4. Click **Start**. **Expected:** Game starts; pieces spawn and fall; HUD updates (score, level, lines).
5. Play a few moves: move left/right, rotate, soft drop, hard drop. **Expected:** Only this board reacts; no errors.

### 2. Second player joins (same world)

1. In **Browser B**, open the game and join the **same world**.
2. **Expected:** Second player gets a **different** plot (e.g. `plot_1`). Camera in B shows **their** board, not Player A’s.
3. In B, type `/myplot`. **Expected:** Different plot id (e.g. `plot_1`) and different coordinates.
4. In B, click **Start**. **Expected:** B’s game starts independently.

### 3. Isolated gameplay (no cross-affection)

1. In **Browser A**: move/rotate/drop pieces and clear some lines. Note A’s score/lines.
2. In **Browser B**: do different moves (e.g. only move left, or hard drop).
3. **Expected:**
   - A’s HUD shows only A’s score/lines/level/next.
   - B’s HUD shows only B’s score/lines/level/next.
   - Moving in A does **not** change B’s board, and vice versa.
4. Optional: in A type `/reset`. **Expected:** Only A’s board resets; B’s board unchanged.

### 4. Commands

- In A: `/myplot` → A’s plot id and origin.
- In B: `/myplot` → B’s plot id and origin (different).
- Either: `/plots` → List of all plots and which player id (or "free") is assigned.
- In A: `/reset` → Only A’s game resets.

### 5. Leave / rejoin

1. In **Browser B**, leave the world (disconnect or switch world).
2. **Expected:** B’s plot is freed; their board region is cleared (no leftover blocks).
3. In **Browser A**, keep playing. **Expected:** A’s game continues; no crash.
4. Rejoin with **Browser B**. **Expected:** B gets a plot again (possibly same or different); new game on that plot.

### 6. All plots full (optional, need 9+ clients to fill 8 plots)

1. With 8 players in the world (each with a plot), have a **ninth** player join.
2. **Expected:** Ninth player sees "All plots full. Wait for a free plot." (or similar); no plot assigned; no crash.
3. One player leaves. **Expected:** That plot freed. Next joiner (or the waiting ninth) can get a plot.

## Quick Sanity Checklist

- [ ] Two players in same world each have their own board and HUD.
- [ ] Moving/rotating/dropping in one window does not change the other’s board.
- [ ] `/myplot` and `/plots` show correct assignment.
- [ ] `/reset` only resets the typing player’s instance.
- [ ] When a player leaves, their plot is cleared and freed; no crash with 0 players or rapid join/leave.

---

# Battle Mode — How to Test

Same setup: server running (`npm run dev`), two browser windows (or one normal + one incognito) for two distinct players in the same world.

## 1. Create a room (Player A)

1. In **Browser A**, join the world (solo Tetris as usual).
2. In chat, type: **`/battle create`**
3. **Expected:** Reply like `Battle room created. Code: ABC123. Share it for others to /battle join ABC123`
4. Note the code (e.g. `ABC123`).

## 2. Join the room (Player B)

1. In **Browser B**, join the **same world**.
2. In chat, type: **`/battle join ABC123`** (use the code from step 1).
3. **Expected:** Reply like `Joined battle room ABC123. Host can /battle start when ready.`

## 3. Start the match (Host only)

1. In **Browser A** (the host), type: **`/battle start`**
2. **Expected:** Reply `Match starting! Good luck.`
3. **Expected:**
   - Both players are teleported to the battle booth (far from solo plots).
   - Two boards appear side-by-side in the world (Player A’s board and Player B’s board).
   - HUD switches to **battle layout**: left = Player A, right = Player B, with room line “Room: ABC123 | Spectators: 0 | Status: Playing”.
   - Your side is highlighted (border); scores, lines, and “Incoming” garbage count show for both.
   - Energy meter and Power-up (E) appear at the bottom.

## 4. Play the battle

- **Clear lines** → garbage is sent to the other player’s board (after a short delay). You should see “Incoming” increase on the other side and then garbage lines appear on their board.
- **Earn energy** by clearing lines; at 4 energy you get a random power-up (Shield, Jam, or Swap).
- **Use power-up:** press **E** or tap the “Power-up (E)” button. Shield blocks incoming garbage; Jam slows the opponent’s left/right; Swap changes your next three pieces.
- First player to **top out** (piece can’t spawn) loses; match ends and both return to solo plots.

## 5. Spectator (optional, third client)

1. Open the game in a **third** browser (or another tab with a different account).
2. Join the same world.
3. While the match is running, type: **`/battle spectate ABC123`**
4. **Expected:** That player is teleported to the spectator platform and sees the **spectator HUD**: “SPECTATING ROOM ABC123”, both boards side-by-side, both scores/lines. No energy/power-up controls (they’re not playing).

## 6. Leave or end match

- **Leave room anytime (before or after match):** type **`/battle leave`**. If the host leaves, the room is disbanded.
- **After game over:** Match ends automatically; both boards are cleared, the booth is released, and both players are back on solo plots. You can create/join a new room and start again.

## Battle commands summary

| Command | Who | Effect |
|--------|-----|--------|
| `/battle create` | Anyone | Create room; you become host and Player A. |
| `/battle join <CODE>` | Anyone | Join as Player B (room must be waiting). |
| `/battle spectate <CODE>` | Anyone | Watch an in-progress or waiting room. |
| `/battle start` | Host only | Start the match (needs 2 players). |
| `/battle leave` | Anyone in a room | Leave the room (host leaving disbands it). |

## Quick battle checklist

- [ ] Two players: create room (A), join (B), start (A) → both at booth, two boards in-world and in HUD.
- [ ] Clearing lines sends garbage to the other board; power-ups (E) work (Shield/Jam/Swap).
- [ ] Spectator can join with `/battle spectate <CODE>` and sees both boards + banner.
- [ ] Game over clears boards and returns both to solo; booth can be reused for a new room.
- [ ] Solo mode is unchanged when not in a battle (no battle HUD, normal plot play).
